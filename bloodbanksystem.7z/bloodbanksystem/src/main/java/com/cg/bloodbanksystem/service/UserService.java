package com.cg.bloodbanksystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.cg.bloodbanksystem.entity.Student;
import com.cg.bloodbanksystem.entity.user.BloodRequest;
import com.cg.bloodbanksystem.entity.user.User;
import com.cg.bloodbanksystem.repository.StudentRepository;
import com.cg.bloodbanksystem.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	UserRepository userRepository;

	@Autowired
	StudentRepository studentRepository;

	@Autowired
	private JavaMailSender javaMailSender;

	public List<User> getAllUsers() {
		// TODO Auto-generated method stub
		return userRepository.findAll();
	}

	public Page<User> getUserByName(int page, int size, String name) {

		Pageable paging = PageRequest.of(page, size, Sort.by("userFirstName"));
		Page<User> pagedResult;
		if (name.isEmpty()) {
			pagedResult = userRepository.findAll(paging);
		} else {
			pagedResult = userRepository.findByUserFirstName(name, paging);
		}

		// Page<User> pagedResult = userRepository.findAll(paging);

		return pagedResult;
	}

	public Page<User> getAllUsersPaginationSorting(int page, int size, String sortBy) {
		// TODO Auto-generated method stub

		if (sortBy.equalsIgnoreCase("userGender")) {

			Pageable pageable = PageRequest.of(page, size, Sort.by(sortBy).descending());
			Page<User> pagedResult = userRepository.findAll(pageable);
			return pagedResult;

		} else {

			Pageable paging = PageRequest.of(page, size, Sort.by(sortBy));
			Page<User> pagedResult = userRepository.findAll(paging);
			return pagedResult;
		}

		// return userRepository.findAll();
	}

	public User createNewUser(User user) {

		User user2 = userRepository.findByUserEmail(user.getUserEmail());
		if (user2 == null) {
			return userRepository.save(user);
		} else {
			return null;
		}

	}

	public Student saveStudent(Student student) {
		// TODO Auto-generated method stub
		return studentRepository.save(student);
	}

	public BloodRequest sendRequestToAllUsers(BloodRequest bloodRequest) {

		List<User> userBloodList = userRepository.findByUserBloodGroup(bloodRequest.getPatientBloodgroup());

		for (User user : userBloodList) {
			List<BloodRequest> userBloodRequests = user.getBloodRequests();
			if (userBloodRequests.isEmpty()) {
				user.getBloodRequests().add(bloodRequest);
				// sendEmail(user.getUserEmail());
			} else {
				boolean find = false;
				for (BloodRequest userBloodRequest : userBloodRequests) {
					if (userBloodRequest.getPatientFirstName().equals(bloodRequest.getPatientFirstName())
							&& userBloodRequest.getPatientPhone().equals(bloodRequest.getPatientPhone())) {
						find = true;
					}
				}
				if (!find) {
					userBloodRequests.add(bloodRequest);
				}
			}
			updateUser(user);
		}

		return bloodRequest;

	}

	public boolean updateUser(User user) {
		User repoUser = userRepository.findByUserId(user.getUserId());
		repoUser.setUserPhone(user.getUserPhone());
		repoUser.setUserFirstName(user.getUserFirstName());
		repoUser.setUserLastName(user.getUserLastName());
		if (userRepository.save(repoUser) != null) {
			return true;
		} else {
			return false;
		}
	}

	public User verifyUser(User user) {
		// TODO Auto-generated method stub
		User user2 = userRepository.findByUserEmail(user.getUserEmail());
		if (user2 != null) {
			if (user.getUserPassword().equals(user2.getUserPassword())) {
				return user2;
			}
		}
		return null;

	}

	public List<BloodRequest> getBloodRequestForUser(String userName) {
		// TODO Auto-generated method stub
		User user = userRepository.findByUserFirstName(userName);
		return user.getBloodRequests();
	}

	public User acceptBloodRequest(String userEmail, BloodRequest bloodRequest) {

		User user = userRepository.findByUserEmail(userEmail);
		List<User> users = userRepository.findByUserBloodGroup(bloodRequest.getPatientBloodgroup());
		for (User user2 : users) {
			List<BloodRequest> list = user2.getBloodRequests();
			for (BloodRequest userBloodRequest : list) {
				if (userBloodRequest.getPatientPhone().equals(bloodRequest.getPatientPhone())
						&& userBloodRequest.getPatientFirstName().equals(bloodRequest.getPatientFirstName())) {
					userBloodRequest.setAccepted(true);
				}
			}
			userRepository.save(user);
		}

		return userRepository.save(user);
	}

	public User getUserById(int userId) {
		// TODO Auto-generated method stub
		return userRepository.findByUserId(userId);
	}

	public void sendEmail(String email) {

		SimpleMailMessage msg = new SimpleMailMessage();
		msg.setTo(email);

		msg.setSubject("Blood requirment");
		msg.setText("Hello World \n Spring Boot Email");

		javaMailSender.send(msg);

	}

}
