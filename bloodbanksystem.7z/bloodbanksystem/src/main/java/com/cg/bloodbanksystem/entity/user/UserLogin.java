package com.cg.bloodbanksystem.entity.user;

public class UserLogin {

	private String userLoginEmail;
	private String userLoginPassword;

	public UserLogin(String userLoginEmail, String userLoginPassword) {
		this.userLoginEmail = userLoginEmail;
		this.userLoginPassword = userLoginPassword;
	}

	public String getUserLoginEmail() {
		return userLoginEmail;
	}

	public void setUserLoginEmail(String userLoginEmail) {
		this.userLoginEmail = userLoginEmail;
	}

	public String getUserLoginPassword() {
		return userLoginPassword;
	}

	public void setUserLoginPassword(String userLoginPassword) {
		this.userLoginPassword = userLoginPassword;
	}

}
