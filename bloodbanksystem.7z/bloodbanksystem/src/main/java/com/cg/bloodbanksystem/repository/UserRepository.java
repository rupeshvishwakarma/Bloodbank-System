package com.cg.bloodbanksystem.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.cg.bloodbanksystem.entity.user.User;

@Repository
public interface UserRepository
		extends JpaRepository<User, Integer>, CrudRepository<User, Integer>, PagingAndSortingRepository<User, Integer> {

	Page<User> findByUserFirstName(String user_name , Pageable pageable);
	User findByUserFirstName(String user_name);
	User findByUserEmail(String userEmail);
	List<User> findByUserBloodGroup(String patient_bloodgroup);
	User findByUserId(int userId);

}
