package com.cg.bloodbanksystem.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.cg.bloodbanksystem.entity.BloodRequest;

@Repository
public interface BloodRequestRepository
		extends JpaRepository<BloodRequest, Integer>, PagingAndSortingRepository<BloodRequest, Integer> {

	//@Query(value = "select * from Blood_Request where patient_name like %?1 AND patient_phone like %?2", nativeQuery = true)
	BloodRequest findByPatientFirstNameAndPatientPhone(String patientFirstname, String patientPhone);

}
