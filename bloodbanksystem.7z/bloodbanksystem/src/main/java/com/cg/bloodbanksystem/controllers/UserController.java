package com.cg.bloodbanksystem.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bloodbanksystem.entity.Student;
import com.cg.bloodbanksystem.entity.user.BloodRequest;
import com.cg.bloodbanksystem.entity.user.User;
import com.cg.bloodbanksystem.service.UserService;

@CrossOrigin(origins = "http://localhost:4200", maxAge = 3600)
@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	UserService userService;

	@GetMapping("/getallusers")
	public Page<User> getAllUsers(@RequestParam(defaultValue = "0", value = "page") int page,
			@RequestParam("size") int size,
			@RequestParam(defaultValue = "userFirstName", value = "sortBy") String sortBy) {
		return userService.getAllUsersPaginationSorting(page, size, sortBy);
		// return userService.getAllUsers();
	}

	@PostMapping("/createuser")
	public User createNewUser(@RequestBody User user) {
		return userService.createNewUser(user);
	}

	@GetMapping("/getbloodrequestforuser/{userName}")
	public List<BloodRequest> getBloodRequestForUser(@PathVariable("userName") String user_name) {
		return userService.getBloodRequestForUser(user_name);
	}

	@PostMapping("/sendRequestToAllUsers")
	public BloodRequest sendRequestToAllUsers(@RequestBody BloodRequest bloodRequest) {
		return userService.sendRequestToAllUsers(bloodRequest);
	}

	@PostMapping("/save-student")
	public Student saveStudent(@RequestBody Student student) {
		return userService.saveStudent(student);
	}

	@PostMapping("/verifyuser")
	public User verifyUser(@RequestBody User user) {
		return userService.verifyUser(user);
	}

	@PutMapping("/acceptbloodrequest/{useremail}")
	public User acceptBloodRequest(@PathVariable("useremail") String userEmail,
			@RequestBody BloodRequest bloodRequest) {
		return userService.acceptBloodRequest(userEmail, bloodRequest);
	}

	@GetMapping("/getuserbyname")
	public Page<User> getUserByName(@RequestParam(defaultValue = "0", value = "page") int page,
			@RequestParam("size") int size, @RequestParam("name") String name) {
		return userService.getUserByName(page, size, name);
		// return userService.getAllUsers();
	}

	@GetMapping("/getuserbyid")
	public User getUserById(@RequestParam int userId) {
		return userService.getUserById(userId);
		// return userService.getAllUsers();
	}

	@PostMapping("update-user/{userId}")
	public boolean updateStudent(@RequestBody User user, @PathVariable("userId") int userId) {
		user.setUserId(userId);
		return userService.updateUser(user);
	}

	@GetMapping("/sendEmail")
	public void senEmail() {
		userService.sendEmail("rrv90794@gmail.com");
	}
}
