package com.cg.bloodbanksystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bloodbanksystem.entity.AdminLogin;
import com.cg.bloodbanksystem.exception.AdminException;
import com.cg.bloodbanksystem.repository.AdminRepository;

@Service
public class AdminService {

	@Autowired
	AdminRepository adminRepository;

	public AdminLogin verifyAdmin(AdminLogin admin) throws AdminException {
		AdminLogin adminGotFromQuery = adminRepository.findByAdminLoginEmail(admin.getAdminLoginEmail());
		if (adminGotFromQuery != null) {
			if (adminGotFromQuery.getAdminLoginPassword().equals(admin.getAdminLoginPassword())) {
				return adminGotFromQuery;
			}
		}
		else {
			return null;
			//throw new AdminException("Wrong email or password!");
		}
		return null;
	}

	public List<AdminLogin> getAllAdmin() {
		// TODO Auto-generated method stub
		return adminRepository.findAll();

	}

	public AdminLogin createNewAdmin(AdminLogin admin) {
		return adminRepository.save(admin);
	}

}
