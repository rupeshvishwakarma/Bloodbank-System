package com.cg.bloodbanksystem.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bloodbanksystem.entity.BloodRequest;
import com.cg.bloodbanksystem.repository.BloodRequestRepository;
import com.cg.bloodbanksystem.service.BloodRepositoryService;

@CrossOrigin(origins = "http://localhost:4200", maxAge = 3600)
@RestController
@RequestMapping("/bloodrequest")
public class BloodRequestController {

	@Autowired
	BloodRequestRepository bloodRequestRepository;

	@Autowired
	BloodRepositoryService bloodRepositoryService;

	@GetMapping("/getallbloodrequest")
	public Page<BloodRequest> getAllBloodRequest(@RequestParam(defaultValue = "0", value = "page") int page,
			@RequestParam("size") int size) {
		return bloodRepositoryService.getAllBloodRequest(page, size);
	}

	@PostMapping("/createbloodrequest")
	public BloodRequest createNewUser(@RequestBody BloodRequest bloodRequest) {
		return bloodRequestRepository.save(bloodRequest);
	}

	@PostMapping("/acceptBloodRequest/{useremail}")
	public BloodRequest acceptBloodRequest(@PathVariable("useremail") String userEmail,
			@RequestBody BloodRequest bloodRequest) {
		return bloodRepositoryService.acceptBloodRequest(bloodRequest, userEmail);
	}

	@PostMapping("/rejectRequest")
	public BloodRequest rejectRequest(@RequestBody BloodRequest bloodRequest) {
		return bloodRepositoryService.rejectRequest(bloodRequest);
	}
}
