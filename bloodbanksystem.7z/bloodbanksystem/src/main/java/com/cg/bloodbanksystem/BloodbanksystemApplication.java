package com.cg.bloodbanksystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BloodbanksystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(BloodbanksystemApplication.class, args);
	}

}