package com.cg.bloodbanksystem.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.cg.bloodbanksystem.entity.BloodRequest;
import com.cg.bloodbanksystem.repository.BloodRequestRepository;
import com.cg.bloodbanksystem.repository.UserRepository;

@Service
public class BloodRepositoryService {

	@Autowired
	BloodRequestRepository bloodRequestRepository;

	@Autowired
	UserRepository userRepository;

	public BloodRequest acceptBloodRequest(BloodRequest bloodRequest, String userEmail) {

		BloodRequest bloodRequest2 = bloodRequestRepository
				.findByPatientFirstNameAndPatientPhone(bloodRequest.getPatientFirstName(), bloodRequest.getPatientPhone());

		bloodRequest2.setAccepted(true);

		return bloodRequestRepository.save(bloodRequest2);

	}

	public BloodRequest rejectRequest(BloodRequest bloodRequest) {
		BloodRequest bloodRequest2 = bloodRequestRepository
				.findByPatientFirstNameAndPatientPhone(bloodRequest.getPatientFirstName(), bloodRequest.getPatientPhone());
		bloodRequest2.setRejected(true);

		return bloodRequestRepository.save(bloodRequest2);
	}

	public Page<BloodRequest> getAllBloodRequest(int page, int size) {
		Pageable paging = PageRequest.of(page, size);
		Page<BloodRequest> pagedResult = bloodRequestRepository.findAll(paging);

//		System.out.println(pagedResult.getTotalElements());
//		System.out.println(pagedResult.getTotalPages());

		return pagedResult;
	}

}
