package com.cg.bloodbanksystem.entity.user;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "BloodRequestForUsers")
public class BloodRequest {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "bloodrequest_id_for_donors")
	private int bloodrequestIdForDonors;

	private String patientFirstName;
	private String patientLastName;
	private Date patientDateofbirth;
	private String patientGender;
	private String patientPhone;
	private String patientBloodgroup;
	private String patientHospital;

	private boolean accepted;

	@Column(name = "userId")
	private int userId;

	public int getBloodrequestIdForDonors() {
		return bloodrequestIdForDonors;
	}

	public void setBloodrequestIdForDonors(int bloodrequestIdForDonors) {
		this.bloodrequestIdForDonors = bloodrequestIdForDonors;
	}

	public String getPatientFirstName() {
		return patientFirstName;
	}

	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}

	public String getPatientLastName() {
		return patientLastName;
	}

	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}

	public Date getPatientDateofbirth() {
		return patientDateofbirth;
	}

	public void setPatientDateofbirth(Date patientDateofbirth) {
		this.patientDateofbirth = patientDateofbirth;
	}

	public String getPatientGender() {
		return patientGender;
	}

	public void setPatientGender(String patientGender) {
		this.patientGender = patientGender;
	}

	public String getPatientPhone() {
		return patientPhone;
	}

	public void setPatientPhone(String patientPhone) {
		this.patientPhone = patientPhone;
	}

	public String getPatientBloodgroup() {
		return patientBloodgroup;
	}

	public void setPatientBloodgroup(String patientBloodgroup) {
		this.patientBloodgroup = patientBloodgroup;
	}

	public String getPatientHospital() {
		return patientHospital;
	}

	public void setPatientHospital(String patientHospital) {
		this.patientHospital = patientHospital;
	}

	public boolean isAccepted() {
		return accepted;
	}

	public void setAccepted(boolean accepted) {
		this.accepted = accepted;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

}
