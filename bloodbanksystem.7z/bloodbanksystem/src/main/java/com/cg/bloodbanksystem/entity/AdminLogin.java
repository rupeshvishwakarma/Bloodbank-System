package com.cg.bloodbanksystem.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "admin")
public class AdminLogin {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int adminId;

	private String adminLoginEmail;
	private String adminLoginPassword;

	public int getAdminId() {
		return adminId;
	}

	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}

	public String getAdminLoginEmail() {
		return adminLoginEmail;
	}

	public void setAdminLoginEmail(String adminLoginEmail) {
		this.adminLoginEmail = adminLoginEmail;
	}

	public String getAdminLoginPassword() {
		return adminLoginPassword;
	}

	public void setAdminLoginPassword(String adminLoginPassword) {
		this.adminLoginPassword = adminLoginPassword;
	}

}
